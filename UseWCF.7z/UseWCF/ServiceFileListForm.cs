﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WCFClient;

namespace WCFClient
{
    public partial class ServiceFileListForm : Form
    {
        private DataSet _dataSet = new DataSet();

        public string selectedFile = "";

        public ServiceFileListForm()
        {
            InitializeComponent();

            _dataSet = ClientForm.serviceFileList;
            DataTable dataTable = _dataSet.Tables[0].Copy();
            string[] splitString;
            this.lsbFileList.ColumnWidth = 85;
            for (var j = 0; j < dataTable.Rows.Count; j++)
            {
                splitString = dataTable.Rows[j]["FileName"].ToString().Split('\\');
                lsbFileList.Items.Add(splitString[splitString.Length - 1]);
            }
                
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (lsbFileList.SelectedItem != null)
            {
                selectedFile = lsbFileList.SelectedItem.ToString();
                this.Close();
            }
            else
                this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

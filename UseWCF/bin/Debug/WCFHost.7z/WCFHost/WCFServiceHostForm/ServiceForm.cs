﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using WCFHost;
using System.Threading;

namespace WCFServiceHostForm
{
    public partial class ServiceForm : Form
    {
        public ServiceForm()
        {
            InitializeComponent();

        }
        private static readonly object InstObj = new object();
        private int selectedFlag = 0;
        private int selectedIndex = -1;
        private void Form1_Load(object sender, EventArgs e)
        {
            ServiceHost host = new ServiceHost(typeof(Service1));
            host.Open(); // Start Listening

            #region Thread Working

            Thread threadSendMessage = new Thread(new ThreadStart(delegate   //Listen all clients chat content
            {
                //lock (InstObj)//Lock for multiple
                //{
                while (true)
                {
                    if (Service1._isSendMessage == true) // Listen chat
                    {
                        SendToOtherClient(Service1._sendMessenger, Service1._receiveMessenger);
                    }
                    else if (Service1._isNewUser == true) // Listen login
                    {
                        AddNewUser();
                    }

                    Thread.Sleep(10);
                }
                //}
            }));
            threadSendMessage.IsBackground = true;
            threadSendMessage.Start();

            #endregion
        }
        
        private void AddNewUser()
        {
            string sessionID = "";
            List<string> userList = new List<string>();
            if (Service1._dicHostSessionid != null || Service1._dicHostSessionid.Count > 0)
            {
                this.Invoke(new MethodInvoker(delegate { this.lsbUserList.Items.Clear(); }));
                foreach (var clientList in Service1._dicHostUserid) // id.key = userName, id.Value = sessionID
                {
                    userList.Add(clientList.Key);

                    this.Invoke(new MethodInvoker(delegate
                    {
                        this.lsbUserList.Items.Add(clientList.Key); // UserList put in Service
                    }));
                }

                foreach (var users in Service1._dicHostSessionid) // Update all client's list
                {
                    sessionID = users.Key;
                    Service1._dicHostSessionid[sessionID].UpdateUserList(userList);
                }
            }
            Service1._isNewUser = false; // Initialize
        }
        private void SendToOtherClient(Person person, string specificClient)
        {
            string sessionID = Service1._dicHostUserid[person._userName];
            if (specificClient != "")
            {
                if (specificClient == "Service")
                {
                    this.Invoke(new MethodInvoker(delegate
                    {
                        this.rtbHistory.SelectionColor = Color.Green;
                        this.rtbHistory.AppendText(person._userName + "[to you] : " + person._chatContent + "\n");
                        this.rtbHistory.SelectionColor = Color.White;
                    }));
                }
                else 
                {
                    sessionID = Service1._dicHostUserid[specificClient];
                    Service1._dicHostSessionid[sessionID].SendMessage(person, 3);
                }
            }
            else
            {
                foreach (var id in Service1._dicHostSessionid) // Broadcast message to other clients without the one who send this message
                {
                    if (id.Key.ToString() != sessionID)
                        id.Value.SendMessage(person, 2);
                }

                this.Invoke(new MethodInvoker(delegate
                { 
                    this.rtbHistory.AppendText(person._userName + " : " + person._chatContent + "\n"); 
                }));
            }
            Service1._isSendMessage = false; // Initialize
        }

        #region Toolbox Event
        private void btnBroadCast_Click(object sender, EventArgs e)
        {
            Person person = new Person();
            person._userName = "Service";
            person._chatContent = this.txtChat.Text;
            if (txtChat != null && lsbUserList.SelectedItem != null)
            {
                string selectedItem = lsbUserList.SelectedItem.ToString();
                if (Service1._dicHostUserid.ContainsKey(selectedItem))
                {
                    string sessionID = Service1._dicHostUserid[selectedItem];
                    Service1._dicHostSessionid[sessionID].SendMessage(person, 1); // Service to specific client

                    rtbHistory.SelectionColor = Color.Red;
                    rtbHistory.AppendText(person._userName + "[to " + selectedItem + "] : " + person._chatContent + "\n");
                    rtbHistory.SelectionColor = Color.White;
                }
            }
            else
            {
                foreach (var id in Service1._dicHostSessionid)
                {
                    id.Value.SendMessage(person, 0);// Broadcast message to every client
                }
                this.rtbHistory.AppendText(person._userName + " : " + person._chatContent + "\n"); // Add text into ChatBoard
            }
            
        }
        private void btnFile_Click(object sender, EventArgs e)
        {
            
        }
        private void lsbUserList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsbUserList.SelectedIndex == selectedIndex && selectedFlag == 1)
            {
                lsbUserList.SelectedIndex = -1;
                selectedFlag = 0;
            }
            else
            {
                selectedIndex = lsbUserList.SelectedIndex;
                selectedFlag = 1;
            }
        }
        #endregion
    }
}
